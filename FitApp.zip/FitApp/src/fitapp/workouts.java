/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fitapp;

/**
 *
 * @author Jeremy
 */
public class workouts {
    profile prof;
    String result; 
    workouts(profile prof){
        this.prof = prof; 
    
}
    public String calculcateWorkout(){
             if(prof.getWeight()<100&&prof.getGoal().equals("gain lean muscle mass")){
        result = "MONDAY \n\n"
                 + "Machine Press\n" +
"3 sets of 7-10 reps.\n\n" +
"1-3 minutes rest between sets.\n" +
"Cable flys\n" +
"3 sets of 7-10 reps. Then one more set until failure\n" +
"1-3 minutes rest between sets.\n\n" +
"Incline Dumbbell Press\n\n" +
"3 sets of 7-10 reps.\n" +
"1-3 minutes rest between sets.\n\n"
                 + "TUESDAY \n\n" +
                 
"Lat Pull-Downs\n\n" +
"3 sets of 8-10 reps.\n" +
"1-2 minutes rest between sets.\n\n" +
"Lateral Raises\n\n" +
"2 sets of 10-15 reps.\n" +
"1 minute rest between sets.\n\n" +
"Rows\n\n" +
"3 sets of 10-12 reps.\n" +
"1 minute rest between sets.\n\n" +
"Dumbbell Curls\n\n" +
"3 sets of 12-16 reps.\n" +
"1 minute rest between sets. Then one more set until failure \n\n"
                 + "WEDNESDAY\n\n"
                 + "Squats\n\n" +
"3 sets of 6-8 reps.\n" +
"2-3 minutes rest between sets.\n\n" +
"Split Squats \n\n" +
"3 sets of 8-10 reps.\n" +
"3-5 minutes rest between sets.\n\n" +
"Lying Leg Curls\n\n" +
"3 sets of 10-12 reps.\n" +
"1-2 minutes rest between sets.\n\n" +
"Seated Calf Raises\n\n" +
"4 sets of 12-16 reps.\n" +
"1-2 minutes rest between sets.\n\n"
                 + "THURSDAY \n\n "
                 + "Lateral flys \n\n"
                 + "3 sets of 10-12 reps. Then one more set untul failure\n"
                 + "1-2 minutes of rest between sets\n\n"
                 + "Overhead shoulder press\n\n"
                 + "3 sets 8-10 reps\n"
                 + "1-2 minutes of rest between\n\n"
                 + "Upright row\n\n "
                 + "3 sets of 8-10 reps \n "
                 + "1-2 minute rests in between \n\n"
                 + "Front Raise \n\n"
                 + "3 sets of 8-10 reps \n"
                 + "2-3 minutes of rest in between\n\n"
                 + "FRIDAY \n\n" +
"Abs\n\n" +
"5 sets of 8-15 reps.\n" +
"1 minute rest between sets."; 
       }
         else if(prof.getWeight()< 200 &&prof.getGoal().equals("gain lean muscle mass")){
            result ="MONDAY \n\n"
                 + "Bench Press\n" +
"3 sets of 6-8 reps.\n\n" +
"2-3 minutes rest between sets.\n" +
"push ups\n" +
"3 sets of 15-20 reps.\n" +
"2-3 minutes rest between sets.\n\n" +
"Incline Dumbbell Press\n\n" +
"3 sets of 5-8 reps.\n" +
"1-2 minutes rest between sets.\n\n"
                    
                 + "TUESDAY \n\n" +
                 
"Lat Pull-Downs\n\n" +
"3 sets of 5-8 reps.\n" +
"1-2 minutes rest between sets.\n\n" +
"Lateral Raises\n\n" +
"2 sets of 5-8reps.\n" +
"1 minute rest between sets.\n\n" +
"Close grip pullups\n\n" +
"3 sets of 6-8 reps.\n" +
"1 minute rest between sets.\n\n" +
"Dumbbell Curls\n\n" +
"3 sets of 10-12 reps.\n" +
"1 minute rest between sets. \n\n"
                    
                   
                 + "WEDNESDAY\n\n"
                 + "Squats\n\n" +
"3 sets of 6-8 reps.\n" +
"2-3 minutes rest between sets.\n\n" +
"Lunges \n\n" +
"3 sets of 6-8 reps.\n" +
"1-2 minutes rest between sets.\n\n" +
"Leg extensions Curls\n\n" +
"3 sets of 10-12 reps.\n" +
"1-2 minutes rest between sets.\n\n" +
"Standing calf Raises\n\n" +
"3 sets of 12-15 reps.\n" +
"1-2 minutes rest between sets.\n\n"
                 + "THURSDAY \n\n"
                 + "Tricep pushdowns\n\n"
                 + "3 sets of 8-10 reps\n"
                 + "1-2 minutes of rest between sets\n\n"
                 + "Overhead shoulder press\n\n"
                 + "3 sets 5-8 reps\n"
                 + "3-4 minutes of rest between\n\n"
                 + "Skull crushers\n\n "
                 + "3 sets of 5-8 reps \n "
                 + "1-2 minute rests in between \n\n"
                 + "Close grip bench press \n\n"
                 + "3 sets of 5-8 reps \n"
                 + "2-3 minutes of rest in between\n\n"
                 + "FRIDAY \n\n" +
"Abs\n\n" +
"5 sets of 8-15 reps.\n" +
"1 minute rest between sets.";
        }
        else if(prof.getWeight()>200 &&prof.getGoal().equals("gain lean muscle mass")){
            result ="MONDAY \n\n"
                 + "Bench Press\n" +
"3 sets of 6-8 reps.\n\n" +
"2-3 minutes rest between sets.\n" +
"push ups\n" +
"3 sets of 15-20 reps.\n" +
"2-3 minutes rest between sets.\n\n" +
"Incline Dumbbell Press\n\n" +
"3 sets of 5-8 reps.\n" +
"1-2 minutes rest between sets.\n\n"
                    + "Cardio \n"
                    + "30 minutes on the treadmill, active jog\n"
                    + "5 minute rest\n"
                    + "8-10 minute light sprint \n\n"
                 + "TUESDAY \n\n" +
                 
"Lat Pull-Downs\n\n" +
"3 sets of 5-8 reps.\n" +
"1-2 minutes rest between sets.\n\n" +
"Lateral Raises\n\n" +
"2 sets of 5-8reps.\n" +
"1 minute rest between sets.\n\n" +
"Close grip pullups\n\n" +
"3 sets of 6-8 reps.\n" +
"1 minute rest between sets.\n\n" +
"Dumbbell Curls\n\n" +
"3 sets of 10-12 reps.\n" +
"1 minute rest between sets. \n\n"
                    + "Cardio \n"
                    + "30 minutes on bicycle\n"
                    + "5 minute rest\n\n"
                 + "WEDNESDAY\n\n"
                 + "Squats\n\n" +
"3 sets of 6-8 reps.\n" +
"2-3 minutes rest between sets.\n\n" +
"Lunges \n\n" +
"3 sets of 6-8 reps.\n" +
"1-2 minutes rest between sets.\n\n" +
"Leg extensions Curls\n\n" +
"3 sets of 10-12 reps.\n" +
"1-2 minutes rest between sets.\n\n" +
"Standing calf Raises\n\n" +
"3 sets of 12-15 reps.\n" +
"1-2 minutes rest between sets.\n\n"
                 + "THURSDAY \n\n "
                    + "THURSDAY \n\n"
                    + "Cardio \n"
                    + "30 minute warm up jog\n"
                    + "5 minute rest\n\n"
                    + "Stair master \n"
                    + "15 minutes straight \n\n"
                 + "Tricep pushdowns\n\n"
                 + "3 sets of 8-10 reps\n"
                 + "1-2 minutes of rest between sets\n\n"
                 + "Overhead shoulder press\n\n"
                 + "3 sets 5-8 reps\n"
                 + "3-4 minutes of rest between\n\n"
                 + "Skull crushers\n\n "
                 + "3 sets of 5-8 reps \n "
                 + "1-2 minute rests in between \n\n"
                 + "Close grip bench press \n\n"
                 + "3 sets of 5-8 reps \n"
                 + "2-3 minutes of rest in between\n\n"
                 + "FRIDAY \n\n" +
"Abs\n\n" +
"5 sets of 8-15 reps.\n" +
"1 minute rest between sets.";
        }
        else if(prof.getWeight()<100&&prof.getGoal().equals("lose weight")){
        result = "It is not recommended that you lose weight with a current weight of <=100 lbs"; 
                }
               else if(prof.getWeight()< 200 &&prof.getGoal().equals("lose weight")){
            result ="MONDAY \n\n"
                    + "Cardio \n"
                    + "1hr on the tread mill, light jog\n"
                    + "10 min light sprint\n\n"
                 + "Bench Press\n" +
"3 sets of 10-12 reps.\n\n" +
"1-2 minutes rest between sets.\n" +
"push ups\n" +
"3 sets of 15-20 reps.\n" +
"2-3 minutes rest between sets.\n\n" +
"Cable flys\n\n" +
"3 sets of 10-12 reps.\n" +
"1-2 minutes rest between sets.\n\n"
                    
                 + "TUESDAY \n\n"
                    + "Cardio \n"
                    + "40 min on bicycle\n"
                    + "20 min on eliptical\n\n" +
                 
"Lat Pull-Downs\n\n" +
"3 sets of 10-12 reps.\n" +
"1-2 minutes rest between sets.\n\n" +
"Lateral Raises\n\n" +
"2 sets of 10-12 reps.\n" +
"1 minute rest between sets.\n\n" +
"Far grip pullups\n\n" +
"2 sets of 6-8 reps.\n" +
"1 minute rest between sets.\n\n" +
"Dumbbell Curls\n\n" +
"3 sets of 10-12 reps.\n" +
"1 minute rest between sets. \n\n"
                    
                   
                 + "WEDNESDAY\n\n"
                 + "Squats\n\n" +
"3 sets of 6-8 reps.\n" +
"2-3 minutes rest between sets.\n\n" +
"Lunges \n\n" +
"3 sets of 6-8 reps.\n" +
"1-2 minutes rest between sets.\n\n" +
"Standing calf Raises\n\n" +
"3 sets of 12-15 reps.\n" +
"1-2 minutes rest between sets.\n\n"
                    + "Cardio \n"
                    + "15 min on Stair master\n\n"
                 + "THURSDAY \n\n"
                 + "Reserve this day to eating atleast 22 grams of lean protien,\n in addition to the diet."
                 + "FRIDAY \n\n" +
"Abs\n\n" +
"5 sets of 8-15 reps.\n" +
"1 minute rest between sets.";
        }
       
 else if(prof.getWeight()>200 &&prof.getGoal().equals("lose weight")){
            result ="MONDAY \n\n"
                    + "Cardio \n"
                    + "1hr on the tread mill, light jog\n"
                    + "20 min light sprint\n"
                    + "10 min walk on the treadmill"
               
                    
                 + "TUESDAY \n\n"
                    + "Cardio \n"
                    + "40 min on bicycle\n"
                    + "20 min on eliptical\n\n" +
                 
"Pushups\n\n" +
"3 sets of 10-12 reps.\n" +
"1-2 minutes rest between sets.\n\n" +
"cable flies\n\n" +
"2 sets of 10-12 reps.\n" +
"1 minute rest between sets.\n\n" +
"dips\n\n" +
"2 sets of 6-8 reps.\n" +
"1 minute rest between sets.\n\n" +
"Incline chest press\n\n" +
"3 sets of 10-12 reps.\n" +
"1 minute rest between sets. \n\n"
                    
                   
                 + "WEDNESDAY\n\n"
                 + "Squats\n\n" +
"3 sets of 10-12 reps.\n" +
"2-3 minutes rest between sets.\n\n" +
"Lunges \n\n" +
"3 sets of 10-12 reps.\n" +
"1-2 minutes rest between sets.\n\n" +
"Standing calf Raises\n\n" +
"3 sets of 12-15 reps.\n" +
"1-2 minutes rest between sets.\n\n"
                    + "Cardio \n"
                    + "15 min on Stair master\n\n"
                 + "THURSDAY \n\n"
                 + "Lat Pull-Downs\n\n" +
"3 sets of 10-12 reps.\n" +
"1-2 minutes rest between sets.\n\n" +
"Lateral Raises\n\n" +
"2 sets of 10-12 reps.\n" +
"1 minute rest between sets.\n\n" +
"Far grip pullups\n\n" +
"2 sets of 6-8 reps.\n" +
"1 minute rest between sets.\n\n" +
"Dumbbell Curls\n\n" +
"3 sets of 12-16 reps.\n" +
"1 minute rest between sets. \n\n"
                 + "FRIDAY \n\n" +
"Abs\n\n" +
"5 sets of 8-15 reps.\n" +
"1 minute rest between sets.";
        }
 else if(prof.getWeight()<100&&prof.getGoal().equals("gain strength")){
        result = "Recommended you look into gaining lean muscle mass first\n\n";
              
       }
else if(prof.getWeight()<200&&prof.getGoal().equals("gain strength")){
        result = "Recommended each set is explosive with the max weight you can do\n\n"
                + "MONDAY \n\n"
                 + "Bench Press\n" +
"3 sets of 5-8 reps.\n\n" +
"3-5 minutes rest between sets.\n" +
"Cable flys\n" +
"3 sets of 5-8 reps. Then one more set until failure\n" +
"2-3 minutes rest between sets.\n\n" +
"Incline Dumbbell Press\n\n" +
"3 sets of 5-8 reps.\n" +
"3-5 minutes rest between sets.\n\n"
                 + "TUESDAY \n\n" +
                 
"Lat Pull-Downs\n\n" +
"3 sets of 5-8 reps.\n" +
"3-5 minutes rest between sets.\n\n" +
"Lateral Raises\n\n" +
"3 sets of 5-8 reps.\n" +
"3 minute rest between sets.\n\n" +
"Dumbbell  rows\n\n" +
"3 sets of 6-8 reps.\n" +
"3 minute rest between sets.\n\n" +
"Dumbbell Curls\n\n" +
"3 sets of 10-12 reps.\n" +
"3 minute rest between sets. Then one more set until failure \n\n"
                 + "WEDNESDAY\n\n"
                 + "Squats\n\n" +
"3 sets of 6-8 reps.\n" +
"4-5 minutes rest between sets.\n\n" +
"Incline leg press \n\n" +
"3 sets of 8-10 reps.\n" +
"3-5 minutes rest between sets.\n\n" +
"Lying Leg Curls\n\n" +
"3 sets of 8-10 reps.\n" +
"3-5 minutes rest between sets.\n\n" +
"Seated Calf Raises\n\n" +
"3 sets of 10-12 reps.\n" +
"2-4 minutes rest between sets.\n\n"
                 + "THURSDAY \n\n "
                 + "Lateral flys \n\n"
                 + "3 sets of 5-8 reps. Then one more set untul failure\n"
                 + "3-4 minutes of rest between sets\n\n"
                 + "Overhead shoulder press\n\n"
                 + "3 sets 5-8 reps\n"
                 + "3-5 minutes of rest between\n\n"
                 + "Upright row\n\n "
                 + "3 sets of 8-10 reps \n "
                 + "3-5 minute rests in between \n\n"
                 + "Front Raise \n\n"
                 + "3 sets of 8-10 reps \n"
                 + "2-3 minutes of rest in between\n\n"
      + "FRIDAY \n\n" +
"Reserve to eating an additional 22 grams of protein, \n in addition to the diet plan"; 

       }
             else if(prof.getWeight()>200&&prof.getGoal().equals("gain strength")){
        result = "Recommended each set is explosive with the max weight you can do\n\n"
                + "MONDAY \n\n"
                 + "Bench press\n" +
"3 sets of 5-8 reps.\n\n" +
"3-5 minutes rest between sets.\n" +
"Cable flys\n" +
"3 sets of 5-8 reps. Then one more set until failure\n" +
"2-3 minutes rest between sets.\n\n" +
"Incline Dumbbell Press\n\n" +
"3 sets of 5-8 reps.\n" +
"3-5 minutes rest between sets.\n\n"
                 + "TUESDAY \n\n" +
                 
"Lat Pull-Downs\n\n" +
"3 sets of 5-8 reps.\n" +
"3-5 minutes rest between sets.\n\n" +
"Lateral Raises\n\n" +
"3 sets of 5-8 reps.\n" +
"3 minute rest between sets.\n\n" +
"Dumbbell  rows\n\n" +
"3 sets of 6-8 reps.\n" +
"3 minute rest between sets.\n\n" +
"Dumbbell Curls\n\n" +
"3 sets of 10-12 reps.\n" +
"3 minute rest between sets. Then one more set until failure \n\n"
                 + "WEDNESDAY\n\n"
                 + "Squats\n\n" +
"3 sets of 6-8 reps.\n" +
"4-5 minutes rest between sets.\n\n" +
"Incline leg press \n\n" +
"3 sets of 8-10 reps.\n" +
"3-5 minutes rest between sets.\n\n" +
"Lying Leg Curls\n\n" +
"3 sets of 8-10 reps.\n" +
"3-5 minutes rest between sets.\n\n" +
"Seated Calf Raises\n\n" +
"3 sets of 10-12 reps.\n" +
"2-4 minutes rest between sets.\n\n"
                 + "THURSDAY \n\n "
                 + "Lateral flys \n\n"
                 + "3 sets of 5-8 reps. Then one more set untul failure\n"
                 + "3-4 minutes of rest between sets\n\n"
                 + "Overhead shoulder press\n\n"
                 + "3 sets 5-8 reps\n"
                 + "3-5 minutes of rest between\n\n"
                 + "Upright row\n\n "
                 + "3 sets of 8-10 reps \n "
                 + "3-5 minute rests in between \n\n"
                 + "Front Raise \n\n"
                 + "3 sets of 8-10 reps \n"
                 + "2-3 minutes of rest in between\n\n"
                 + "FRIDAY \n\n" +
"Reserve to eating an additional 22 grams of protein, \n in addition to the diet plan"; 
       }
     return result; 
 } 
}
