/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fitapp;

import java.util.ArrayList;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

public class JSONProgress extends ApplicationFrame {
private ArrayList<profile> data; 
   public JSONProgress( String applicationTitle , String chartTitle,ArrayList<profile> profList ) {
       
      super(applicationTitle);
      data = profList; 
      JFreeChart lineChart = ChartFactory.createLineChart(
         chartTitle,
         "Update iteration","Weight(lbs)",
         createDataset(),
         PlotOrientation.VERTICAL,
         true,true,false);
         
      ChartPanel chartPanel = new ChartPanel( lineChart );
      chartPanel.setPreferredSize( new java.awt.Dimension( 1500 , 1200) );
      setContentPane( chartPanel );
   }

   private DefaultCategoryDataset createDataset( ) {
      DefaultCategoryDataset dataset = new DefaultCategoryDataset();
      for(int i =0; i < getData().size();i++){
          dataset.addValue(getData().get(i).getWeight(), "update", ""+(i+1));
      }
      
      return dataset;
   }

    /**
     * @return the data
     */
    public ArrayList<profile> getData() {
        return data;
    }

    /**
     * @param data the data to set
     */
    public void setData(ArrayList<profile> data) {
        this.data = data;
    }
   
   
}
