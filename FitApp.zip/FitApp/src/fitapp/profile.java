/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fitapp;
import com.google.gson.Gson; 
import java.io.Serializable;
import java.util.ArrayList;
import javax.swing.*;

/**
 *
 * @author Jeremy
 */
public class profile implements Serializable  {
    private String Name = "admin"; 
    private int weight; 
    private String gender;
    private String Username;
    private String Password;
    private String Goal;
    
   
    profile(String name,String Gender, String username, String password){
        Name = name; 
        gender = Gender;
        Username = username; 
        Password = password;
    }

    /**
     * @return the Name
     */
    public String getName() {
        return Name;
    }

    /**
     * @param Name the Name to set
     */
    public void setName(String Name) {
        this.Name = Name;
    }

    /**
     * @return the weight
     */
    public int getWeight() {
        return weight;
    }

    /**
     * @param weight the weight to set
     */
    public void setWeight(int weight) {
        this.weight = weight;
    }


    /**
     * @return the gender
     */
    public String getGender() {
        return gender;
    }

    /**
     * @param gender the gender to set
     */
    public void setGender(String gender) {
        this.gender = gender;
    }

    /**
     * @return the Username
     */
    public String getUsername() {
        return Username;
    }

    /**
     * @param Username the Username to set
     */
    public void setUsername(String Username) {
        this.Username = Username;
    }

    /**
     * @return the Password
     */
    public String getPassword() {
        return Password;
    }

    /**
     * @param Password the Password to set
     */
    public void setPassword(String Password) {
        this.Password = Password;
    }

    /**
     * @return the Goal
     */
    public String getGoal() {
        return Goal;
    }

    /**
     * @param Goal the Goal to set
     */
    public void setGoal(String Goal) {
        this.Goal = Goal;
    }
    
}
