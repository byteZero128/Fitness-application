/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fitapp;

/**
 *
 * @author Jeremy
 */

import javax.swing.*;
import java.awt.*;
class Welcome extends JFrame
{
  Welcome()
  {
    setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
    setTitle("Welcome");
     setSize(700, 700);
  }
 }
