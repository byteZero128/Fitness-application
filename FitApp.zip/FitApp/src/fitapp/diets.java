/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fitapp;

/**
 *
 * @author Jeremy
 */
public class diets {
    private String result; 
   private double proResult; 
   private profile prof;
   private double multiplier; 
   diets(profile p) {
      prof = p; 
   
   }
 public double calculcateProtein(){
 
    if( getProf().getWeight()<100 && getProf().getGoal().equals("lose weight")){
            setMultiplier(1.2); 
    }
    else if(getProf().getWeight()< 200 && getProf().getGoal().equals("lose weight")){
            setMultiplier(0.9); 
    }
    else if(getProf().getWeight()>200&& getProf().getGoal().equals("lose weight")){
            setMultiplier(1.4); 
    }
    else if(getProf().getWeight()<100 && getProf().getGoal().equals("gain lean muscle mass")){
            setMultiplier(1.4); 
    }
    else if(getProf().getWeight()< 200 && getProf().getGoal().equals("gain lean muscle mass")){
            setMultiplier(1.6); 
    }
    else if(getProf().getWeight()>200&& getProf().getGoal().equals("gain lean muscle mass")){
            setMultiplier(1.0); 
    }
     else if(getProf().getWeight()<100 && getProf().getGoal().equals("gain strength")){
            setMultiplier(2.1); 
    }
    else if(getProf().getWeight()< 200 && getProf().getGoal().equals("gain strength")){
            setMultiplier(1.5); 
    }
    else if(getProf().getWeight()>200&& getProf().getGoal().equals("gian strength")){
            setMultiplier(1.2); 
    }
    else {
        System.out.print("In the else block for diet class"); 
    }
        setProResult(Math.rint(getProf().getWeight() * getMultiplier())); 
 
  return getProResult(); 
   
}
 public String calculateResult(){
     
      if(getProf().getWeight()<100&&getProf().getGoal().equals("lose weight")){
            setResult("Here is a list of foods you should be eating to gain muscle\n\n\n"
                    + "2 Eggs at a time \n\n"
                    + "One fillet of salmon(26 grams of protein) \n\n"
                    + "Greek yogurt mixed in with a high protein count supplement \n\n"
                    + "atleast two chicken breasts \n\n"
                    + "Protein shake with added fruits \n\n"
                    + "Two servings of oatmeal at a time \n\n"); 
       }
         else if(getProf().getWeight()< 200&&getProf().getGoal().equals("lose weight")){
            setResult("Here is a list of foods you should be eating to lose weight \n\n\n"
                    + "Leafy greens including kale, spinach, collards, swiss chards \n\n"
                    + "1 fillet of salmon( 26 grams of protein) \n\n"
                    + "1 fillet of cod/tuna( 22 grams of protein) \n\n"
                    + "Cruciferous vegetables including broccoli, cauliflower, cabbage and Brussels sprouts. \n\n"
                    + "2 Lowfat chicken breasts/lean beef \n\n"
                    + "Protein shake with added fruits \n\n"
                    + "Avacado toast \n\n"
                    + "1 serving of oatmeal\n\n");
        }
        else if(getProf().getWeight()>200&&getProf().getGoal().equals("lose weight")){
            setResult("Here is a list of foods you should be eating to lose weight\n\n\n"
                    + "Leafy greens including kale, spinach, collards, swiss chards \n\n"
                    + "1 fillet of salmon( 26 grams of protein \n\n"
                    + "Cruciferous vegetables including broccoli, cauliflower, cabbage and Brussels sprouts. \n\n"
                    + "2 Lowfat chicken breasts/lean beef \n\n"
                    + "Sweet potatoes/ boiled potatoes \n\n"
                    + "Avacado toast \n\n"
                    + "Apple cidar vinegar \n\n");
        }
        else if(getProf().getWeight()<100&&getProf().getGoal().equals("gain lean muscle mass")){
            setResult("Here is a list of foods you should be eating to gain muscle\n\n\n"
                    + "1 Serving of Whey protein shake\n\n"
                    + "1 serving of mass gainer\n\n"
                    + "2 Eggs at a time \n\n"
                    + "One fillet of salmon(26 grams of protein) \n\n"
                    + "Greek yogurt mixed in with a high protein count supplement \n\n"
                    + "atleast two chicken breasts \n\n"
                    + "Protein shake with added fruits \n\n"
                    + "Two servings of oatmeal at a time \n\n"); 
       }
         else if(getProf().getWeight()< 200&&getProf().getGoal().equals("gain lean muscle mass")){
            setResult("Here is a list of foods you should be eating to lose weight \n\n\n"
                    + "2 Servings of Whey Protein shake\n\n"
                    + "Leafy greens including kale, spinach, collards, swiss chards \n\n"
                    + "1 fillet of salmon( 26 grams of protein) \n\n"
                    + "1 fillet of cod/tuna( 22 grams of protein) \n\n"
                    + "3 Lowfat chicken breasts/lean beef \n\n"
                    + "Protein shake with added fruits \n\n"
                    + "Avacado toast \n\n"
                    + "1 serving of oatmeal\n\n");
        }
        else if(getProf().getWeight()>200&&getProf().getGoal().equals("gain lean muscle mass")){
            setResult("Here is a list of foods you should be eating to lose weight\n\n\n"
                    + " 2 servings of Whey Protein Shake \n\n"
                    + "Leafy greens including kale, spinach, collards, swiss chards \n\n"
                    + "2 fillet of salmon( 26 grams of protein \n\n"
                    + "Cruciferous vegetables including broccoli, cauliflower, cabbage and Brussels sprouts. \n\n"
                    + "3 Lowfat chicken breasts/lean beef \n\n"
                    + "Sweet potatoes/ boiled potatoes \n\n"); 
        }
         else if(getProf().getWeight()<100&&getProf().getGoal().equals("gain strength")){
            setResult("Here is a list of foods you should be eating to gain muscle\n\n\n"
                    + "2 servings of Whey protein shake\n\n"
                    + "1 serving of mass gainer\n\n"
                    + "3 Eggs at a time \n\n"
                    + "One fillet of salmon(26 grams of protein) \n\n"
                    + "Greek yogurt mixed in with a high protein count supplement \n\n"
                    + "atleast two chicken breasts \n\n"
                    + "Protein shake with added fruits \n\n"
                    + "Two servings of oatmeal at a time \n\n"); 
       }
         else if(getProf().getWeight()< 200&&getProf().getGoal().equals("gain strength")){
            setResult("Here is a list of foods you should be eating to lose weight \n\n\n"
                    + "2 servings of Whey Protein shake\n\n"
                    + "1 serving mass gainer shake"
                    + "Leafy greens including kale, spinach, collards, swiss chards \n\n"
                    + "1 fillet of salmon( 26 grams of protein) \n\n"
                    + "3 Lowfat chicken breasts/lean beef \n\n"
                    + "1 serving of oatmeal\n\n");
        }
        else if(getProf().getWeight()>200&&getProf().getGoal().equals("gain strength")){
            setResult("Here is a list of foods you should be eating to lose weight\n\n\n"
                    + " 2 servings of Whey Protein Shake \n\n"
                    + "2 fillet of salmon( 26 grams of protein \n\n"
                    + "Cruciferous vegetables including broccoli, cauliflower, cabbage and Brussels sprouts. \n\n"
                    + "3 Lowfat chicken breasts/lean beef \n\n"
                    + "Sweet potatoes/ boiled potatoes \n\n"); 
        }
      else{
            setResult("in the else block"); 
      }
     
     
     return getResult(); 
 }

    /**
     * @return the result
     */
    public String getResult() {
        return result;
    }

    /**
     * @param result the result to set
     */
    public void setResult(String result) {
        this.result = result;
    }

    /**
     * @return the proResult
     */
    public double getProResult() {
        return proResult;
    }

    /**
     * @param proResult the proResult to set
     */
    public void setProResult(double proResult) {
        this.proResult = proResult;
    }

    /**
     * @return the prof
     */
    public profile getProf() {
        return prof;
    }

    /**
     * @param prof the prof to set
     */
    public void setProf(profile prof) {
        this.prof = prof;
    }

    /**
     * @return the multiplier
     */
    public double getMultiplier() {
        return multiplier;
    }

    /**
     * @param multiplier the multiplier to set
     */
    public void setMultiplier(double multiplier) {
        this.multiplier = multiplier;
    }
}